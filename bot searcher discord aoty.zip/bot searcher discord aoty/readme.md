- Discord Search Bot Aoty ! JavaScript-based
- ***
- Version 1.44.20131208 (Previous rev: 1.44.20131125)
- Copyright (c) , A2tt . All rights reserved.
- Code provided by me
- https://aoty.me/

Vous avez besoin de changer tout les emojis et thumbails
dans les commands
! Vérifier a bien modifié la commands xbox au niveau des emojis !
